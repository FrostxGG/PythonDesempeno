
if __name__ == "__main__":
    # Esta parte solo se ejecutará si este archivo se inicia directamente
    import menus
    menus.Menu_home()