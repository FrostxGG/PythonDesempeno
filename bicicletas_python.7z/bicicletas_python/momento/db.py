users = [
    {"name":"pablo","psw":"Juan123"},
    {"name":"kelly","psw":"KellY123"},
    {"name":"lucas","psw":"lUcAs123"}
]
bicicletas = [
    {"id":1,"color":"roja","estado":True},
    {"id":2,"color":"azul","estado":True},
    {"id":3,"color":"verde","estado":True},
    {"id":4,"color":"naranja","estado":True},
    {"id":5,"color":"negra","estado":True},
    {"id":6,"color":"blanca","estado":True}
    ]
h_alquiler = []